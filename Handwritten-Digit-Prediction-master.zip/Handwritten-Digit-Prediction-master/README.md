# Handwritten-Digit-Prediction
Handwritten Digit Prediction using Convolutional Neural Networks in TensorFlow with Keras and Live Example using TensorFlow.js

### Reference
https://medium.com/coinmonks/handwritten-digit-prediction-using-convolutional-neural-networks-in-tensorflow-with-keras-and-live-5ebddf46dc8

### Usage
https://ashwaniydv.github.io/Handwritten-Digit-Prediction/

OR

Just open index.html in browser
